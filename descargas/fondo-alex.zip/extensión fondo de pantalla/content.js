const fondo = chrome.runtime.getURL("fondo.jpg");

// Fondo del body
document.body.style.backgroundImage = `url("${fondo}")`;
document.body.style.backgroundSize = "cover";
document.body.style.backgroundPosition = "center";
document.body.style.backgroundRepeat = "no-repeat";
document.body.style.backgroundAttachment = "fixed";

// Aseguramos que ocupe toda la pantalla
document.documentElement.style.minHeight = "100%";
document.body.style.minHeight = "100%";
